import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { ServiceCard } from '@/components/service-card'

const services = [
  {
    title: "Search Engine Optimization (SEO)",
    description: "Improve your website's visibility in search results and drive organic traffic",
    imageUrl: "/placeholder.svg?height=400&width=600",
    videoUrl: "#",
    features: [
      "Comprehensive website audit and optimization",
      "Keyword research and strategy",
      "On-page and technical SEO",
      "Content optimization and link building",
      "Local SEO optimization"
    ]
  },
  {
    title: "Pay-Per-Click Advertising (PPC)",
    description: "Drive targeted traffic and generate leads through paid search campaigns",
    imageUrl: "/placeholder.svg?height=400&width=600",
    videoUrl: "#",
    features: [
      "Google Ads campaign management",
      "Keyword research and ad copy creation",
      "Landing page optimization",
      "Conversion tracking and optimization",
      "Regular performance reporting"
    ]
  },
  {
    title: "Social Media Marketing",
    description: "Build brand awareness and engage with your audience on social platforms",
    imageUrl: "/placeholder.svg?height=400&width=600",
    videoUrl: "#",
    features: [
      "Social media strategy development",
      "Content creation and curation",
      "Community management",
      "Paid social advertising",
      "Performance analytics and reporting"
    ]
  },
  {
    title: "Content Marketing",
    description: "Create valuable content that attracts and retains your target audience",
    imageUrl: "/placeholder.svg?height=400&width=600",
    videoUrl: "#",
    features: [
      "Content strategy development",
      "Blog post creation",
      "Infographic design",
      "Video content production",
      "Content distribution"
    ]
  },
  {
    title: "Web Design & Development",
    description: "Create stunning, responsive websites that convert visitors into customers",
    imageUrl: "/placeholder.svg?height=400&width=600",
    videoUrl: "#",
    features: [
      "Custom website design",
      "Mobile-responsive development",
      "E-commerce solutions",
      "Website maintenance",
      "Performance optimization"
    ]
  },
  {
    title: "Email Marketing",
    description: "Nurture leads and drive conversions through targeted email campaigns",
    imageUrl: "/placeholder.svg?height=400&width=600",
    videoUrl: "#",
    features: [
      "Email campaign strategy",
      "Newsletter design and creation",
      "Automated email sequences",
      "List segmentation",
      "A/B testing and optimization"
    ]
  },
  {
    title: "Conversion Rate Optimization (CRO)",
    description: "Improve your website's performance and increase conversion rates",
    imageUrl: "/placeholder.svg?height=400&width=600",
    videoUrl: "#",
    features: [
      "User experience analysis",
      "A/B testing",
      "Landing page optimization",
      "Funnel optimization",
      "Analytics and tracking setup"
    ]
  },
  {
    title: "Amazon Marketing",
    description: "Optimize your Amazon listings and increase sales on the platform",
    imageUrl: "/placeholder.svg?height=400&width=600",
    videoUrl: "#",
    features: [
      "Amazon SEO optimization",
      "PPC campaign management",
      "Product listing optimization",
      "Brand content enhancement",
      "Performance tracking"
    ]
  }
]

export default function ServicesPage() {
  return (
    <>
      <Header />
      <main className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h1 className="text-4xl font-bold mb-4">Digital Marketing Services</h1>
            <p className="text-xl text-gray-600">
              Grow Your Client Base With Data-Driven and Targeted Strategies
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <ServiceCard key={index} {...service} />
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}

