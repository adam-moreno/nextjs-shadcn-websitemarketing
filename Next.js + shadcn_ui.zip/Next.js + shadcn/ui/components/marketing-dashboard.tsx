"use client"

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart'
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis } from 'recharts'

// Made-up data for the dashboard
const dashboardData = {
  daily: [
    { date: '2024-03-01', sales: 1200, reach: 5000, impressions: 15000, conversions: 50 },
    { date: '2024-03-02', sales: 1500, reach: 5500, impressions: 17000, conversions: 65 },
    { date: '2024-03-03', sales: 1300, reach: 4800, impressions: 14500, conversions: 55 },
    { date: '2024-03-04', sales: 1700, reach: 6000, impressions: 18000, conversions: 75 },
    { date: '2024-03-05', sales: 1600, reach: 5800, impressions: 17500, conversions: 70 },
    { date: '2024-03-06', sales: 1800, reach: 6200, impressions: 19000, conversions: 80 },
    { date: '2024-03-07', sales: 2000, reach: 6500, impressions: 20000, conversions: 90 },
  ],
  weekly: [
    { date: 'Week 1', sales: 8500, reach: 35000, impressions: 105000, conversions: 380 },
    { date: 'Week 2', sales: 9200, reach: 38000, impressions: 115000, conversions: 420 },
    { date: 'Week 3', sales: 10000, reach: 40000, impressions: 125000, conversions: 450 },
    { date: 'Week 4', sales: 11000, reach: 43000, impressions: 135000, conversions: 500 },
  ],
  monthly: [
    { date: 'Jan', sales: 35000, reach: 150000, impressions: 450000, conversions: 1600 },
    { date: 'Feb', sales: 38000, reach: 160000, impressions: 480000, conversions: 1750 },
    { date: 'Mar', sales: 42000, reach: 175000, impressions: 525000, conversions: 1900 },
  ],
}

const metrics = [
  { key: 'sales', label: 'Sales', prefix: '$', color: 'hsl(var(--chart-1))' },
  { key: 'reach', label: 'Reach', prefix: '', color: 'hsl(var(--chart-2))' },
  { key: 'impressions', label: 'Impressions', prefix: '', color: 'hsl(var(--chart-3))' },
  { key: 'conversions', label: 'Conversions', prefix: '', color: 'hsl(var(--chart-4))' },
]

export function MarketingDashboard() {
  const [selectedMetric, setSelectedMetric] = useState('sales')

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-10 text-center">Marketing Dashboard</h2>
        <Tabs defaultValue="daily" className="space-y-4">
          <div className="flex justify-between items-center">
            <TabsList>
              <TabsTrigger value="daily">Daily</TabsTrigger>
              <TabsTrigger value="weekly">Weekly</TabsTrigger>
              <TabsTrigger value="monthly">Monthly</TabsTrigger>
            </TabsList>
            <Select value={selectedMetric} onValueChange={setSelectedMetric}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select metric" />
              </SelectTrigger>
              <SelectContent>
                {metrics.map((metric) => (
                  <SelectItem key={metric.key} value={metric.key}>
                    {metric.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {Object.entries(dashboardData).map(([period, data]) => (
            <TabsContent key={period} value={period} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {metrics.map((metric) => (
                  <Card key={metric.key}>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">
                        {metric.label}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        {metric.prefix}
                        {data[data.length - 1][metric.key].toLocaleString()}
                      </div>
                      <p className="text-xs text-muted-foreground">
                        +20.1% from last {period.slice(0, -2)}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
              <Card>
                <CardHeader>
                  <CardTitle>{metrics.find(m => m.key === selectedMetric)?.label} Over Time</CardTitle>
                  <CardDescription>
                    Visualizing {selectedMetric} trends for the selected period
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-4">
                  <ChartContainer config={{
                    [selectedMetric]: {
                      label: metrics.find(m => m.key === selectedMetric)?.label,
                      color: metrics.find(m => m.key === selectedMetric)?.color,
                    },
                  }} className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={data}>
                        <XAxis dataKey="date" />
                        <YAxis />
                        <ChartTooltip content={<ChartTooltipContent />} />
                        <Line
                          type="monotone"
                          dataKey={selectedMetric}
                          stroke={metrics.find(m => m.key === selectedMetric)?.color}
                          strokeWidth={2}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </ChartContainer>
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </section>
  )
}

