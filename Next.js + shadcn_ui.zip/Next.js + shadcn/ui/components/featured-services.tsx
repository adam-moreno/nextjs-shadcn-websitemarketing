import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Megaphone, PenTool, BarChart } from 'lucide-react'

const services = [
  {
    title: 'Digital Advertising',
    description: 'Reach your target audience with precision.',
    icon: Megaphone,
  },
  {
    title: 'Brand Strategy',
    description: 'Build a strong, memorable brand identity.',
    icon: PenTool,
  },
  {
    title: 'Analytics & Insights',
    description: 'Make data-driven decisions for your business.',
    icon: BarChart,
  },
]

export function FeaturedServices() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-10 text-center">Our Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card key={index}>
              <CardHeader>
                <service.icon className="h-10 w-10 mb-2 text-blue-500" />
                <CardTitle>{service.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>{service.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

